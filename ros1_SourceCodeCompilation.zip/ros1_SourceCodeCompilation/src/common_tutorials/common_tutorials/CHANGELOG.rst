^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package common_tutorials
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.9 (2016-12-11)
------------------
* re-insert some old, missing actionlib tutorials
* minor bugfixes here and there

0.1.8 (2014-11-05)
------------------
* update package maintainer.
* Contributors: Daniel Stonier
