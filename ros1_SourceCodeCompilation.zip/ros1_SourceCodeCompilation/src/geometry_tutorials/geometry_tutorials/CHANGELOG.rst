^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package geometry_tutorials
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.4 (2025-04-10)
------------------

0.2.3 (2020-04-02)
------------------
* Bump CMake version to avoid CMP0048 warning (`#29 <https://github.com/ros/geometry_tutorials//issues/29>`_)
* Contributors: Alejandro Hernández Cordero

0.2.2 (2015-03-03)
------------------

0.2.1 (2014-12-17)
------------------
* Added new tutorial for tf2
* Contributors: Denis Štogl

0.2.0 (2013-06-28)
------------------
* Cleaned up build system and package.xml
* geometry_tutorials) Catkinized. Added metapackage.
* Contributors: Isaac Saito, William Woodall
