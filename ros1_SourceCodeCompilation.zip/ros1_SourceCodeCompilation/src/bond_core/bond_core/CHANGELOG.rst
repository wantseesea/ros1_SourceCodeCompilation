^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package bond_core
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.8.7 (2025-04-25)
------------------

1.8.6 (2020-08-28)
------------------

1.8.5 (2020-05-14)
------------------
* Bump CMake minimum version to use CMP0048 (`#58 <https://github.com/ros/bond_core/issues/58>`_)
* Contributors: Michael Carroll

1.8.4 (2020-02-24)
------------------
* Make Michael Carroll the maintainer (`#40 <https://github.com/ros/bond_core/issues/40>`_)
* Contributors: Mikael Arguedas

1.8.3 (2018-08-17)
------------------

1.8.2 (2018-04-27)
------------------

1.8.1 (2017-10-27)
------------------

1.8.0 (2017-07-27)
------------------
* switch to package format 2 (`#27 <https://github.com/ros/bond_core/issues/27>`_)
* Contributors: Mikael Arguedas

1.7.19 (2017-03-27)
-------------------

1.7.18 (2016-10-24)
-------------------

1.7.17 (2016-03-15)
-------------------
* update maintainer
* Contributors: Mikael Arguedas

1.7.16 (2014-10-30)
-------------------

1.7.15 (2014-10-28)
-------------------

1.7.14 (2014-05-08)
-------------------
* Update maintainer field
* Contributors: Esteve Fernandez

1.7.13 (2013-08-21)
-------------------

1.7.12 (2013-06-06)
-------------------

1.7.11 (2013-03-13)
-------------------
* add CMakeLists.txt for metapackage
* Contributors: Dirk Thomas

1.7.10 (2013-01-13)
-------------------

1.7.9 (2012-12-27)
------------------
* modified dep type of catkin
* Contributors: Dirk Thomas

1.7.8 (2012-12-13)
------------------

1.7.7 (2012-12-06)
------------------

1.7.6 (2012-10-30)
------------------

1.7.5 (2012-10-27)
------------------
* clean up package.xml files
* Contributors: Dirk Thomas

1.7.4 (2012-10-06)
------------------
* adding bond_core metapackage to replace former stack
* Contributors: Tully Foote

1.7.3 (2012-10-02 00:19)
------------------------

1.7.2 (2012-10-02 00:06)
------------------------

1.7.1 (2012-10-01 19:00)
------------------------

1.7.0 (2012-10-01 16:51)
------------------------
