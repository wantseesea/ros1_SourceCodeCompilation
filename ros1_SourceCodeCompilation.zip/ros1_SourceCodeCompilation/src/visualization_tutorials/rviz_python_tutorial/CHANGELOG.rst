^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rviz_python_tutorial
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.11.2 (2025-04-26)
-------------------
* Eliminate Python 2 code (`#88 <https://github.com/ros-visualization/visualization_tutorials/issues/88>`_)
* Contributors: vineet131

0.11.1 (2025-04-10)
-------------------
* Update maintainers (`#63 <https://github.com/ros-visualization/visualization_tutorials/issues/63>`_)
* Contributors: Mabel Zhang

0.11.0 (2020-05-13)
-------------------

0.10.4 (2020-05-13)
-------------------
* Updated RViz import (`#60 <https://github.com/ros-visualization/visualization_tutorials/issues/60>`_)
* Updated to use ``catkin_install_python()`` (`#59 <https://github.com/ros-visualization/visualization_tutorials/issues/59>`_)
* Updated required CMake version to avoid CMP0048 warning (`#57 <https://github.com/ros-visualization/visualization_tutorials/issues/57>`_)
* Contributors: Alejandro Hernández Cordero, Shane Loretz

0.10.3 (2018-05-09)
-------------------
* Fixed QWidget not defined bug in rviz_python_tutorial (`#41 <https://github.com/ros-visualization/visualization_tutorials/issues/41>`_)
* Contributors: Zihan Chen

0.10.2 (2018-01-05)
-------------------

0.10.1 (2016-04-21)
-------------------

0.10.0 (2016-04-21)
-------------------

0.9.2 (2015-09-21)
------------------

0.9.1 (2015-01-26)
------------------

0.9.0 (2014-03-24)
------------------
* set myself (william) as maintainer
* Contributors: William Woodall
