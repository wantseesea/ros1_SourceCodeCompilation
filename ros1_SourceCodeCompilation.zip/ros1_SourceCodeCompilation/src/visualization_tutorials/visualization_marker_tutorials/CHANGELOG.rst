^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package visualization_marker_tutorials
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.11.2 (2025-04-26)
-------------------
* Remove '/' (forward slash) from '/my_frame', which frustratingly makes Rviz unable to show the markers. (`#70 <https://github.com/ros-visualization/visualization_tutorials/issues/70>`_)
* Contributors: Phase Le

0.11.1 (2025-04-10)
-------------------
* Update maintainers (`#63 <https://github.com/ros-visualization/visualization_tutorials/issues/63>`_)
* Contributors: Mabel Zhang

0.11.0 (2020-05-13)
-------------------

0.10.4 (2020-05-13)
-------------------
* Updated required CMake version to avoid CMP0048 warning (`#57 <https://github.com/ros-visualization/visualization_tutorials/issues/57>`_)
* Updated to use ``ros::Duration`` for sleeping to gain cross-platform support (`#48 <https://github.com/ros-visualization/visualization_tutorials/issues/48>`_)
* Contributors: Alejandro Hernández Cordero, Sean Yen [MSFT]

0.10.3 (2018-05-09)
-------------------

0.10.2 (2018-01-05)
-------------------

0.10.1 (2016-04-21)
-------------------

0.10.0 (2016-04-21)
-------------------

0.9.2 (2015-09-21)
------------------

0.9.1 (2015-01-26)
------------------
* Now checks number of subscribers before publishing any markers.
* Documented the new DELETEALL feature.
* Contributors: Dave Coleman, Victor Lamoine

0.9.0 (2014-03-24)
------------------
* set myself (william) as maintainer
* Contributors: William Woodall
